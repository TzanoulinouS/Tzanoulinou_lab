%% Step 1: Process normalized coordinates for all entries
%var=FullCPALausanne1;
for n = 1:length(var)
    % Extract original coordinates from data (columns 3 and 4)
    x_original = var(n).data(:, 3);
    y_original = var(n).data(:, 4);
    
    % Initialize normalized coordinates
    x_norm = x_original;
    y_norm = y_original;
    
    % Step 1: Flip top-bottom if pagename is 'Track-Arena alpha-Subject 1'
    if strcmp(var(n).pagename, 'Track-Arena 1-Subject 1')
        % To flip top-bottom, we need the range of y values
        % Since we don't have arena dimensions, we'll use max-min approach
        y_range = range(y_original);
        y_norm = max(y_original) - y_original + min(y_original);
    end
    
    % Step 2: Flip left-right to ensure all cond sides are on left
    if strcmp(var(n).CondSide, 'right')
        % Flip horizontally - similar approach
        x_range = range(x_original);
        x_norm = max(x_original) - x_original + min(x_original);
    end
    
    % Step 3: Normalize to have bottom-left at (0,0)
    x_norm = x_norm - min(x_norm);
    y_norm = y_norm - min(y_norm);
    
    % Update the NormalizedCoordinates field
    var(n).NormalizedCoordinates = [x_norm, y_norm];
end

%% Step 2: Prepare for plotting - collect all data
all_x = [];
all_y = [];
all_cond = [];
colors = [];

for n = 1:length(var)
    % Extract normalized coordinates
    current_coords = var(n).NormalizedCoordinates;
    
    % Extract condition data - convert to double if it's logical
    current_cond = double(var(n).cond); % Convert to 0/1 if logical
    
    % Append to overall arrays
    all_x = [all_x; current_coords(:, 1)];
    all_y = [all_y; current_coords(:, 2)];
    all_cond = [all_cond; current_cond];
    
    % Check what type of data we have in cond
    unique_vals = unique(current_cond);
    fprintf('Entry %d: unique cond values: %s\n', n, mat2str(unique_vals'));
    
    % Assign colors based on condition
    % First, ensure cond values are 0 or 1
    if any(current_cond ~= 0 & current_cond ~= 1)
        % If there are values other than 0/1, map them appropriately
        % Let's assume anything > 0 is condition 1
        current_cond_binary = current_cond > 0;
    else
        current_cond_binary = current_cond;
    end
    
    % Now create colors - use ismember to handle any value
    color_map = [0 0 1; 1 0 0]; % [blue; red]
    
    % Safer color assignment
    current_colors = zeros(length(current_cond_binary), 3);
    for i = 1:length(current_cond_binary)
        if current_cond_binary(i) == 0
            current_colors(i, :) = color_map(1, :); % Blue for 0
        else
            current_colors(i, :) = color_map(2, :); % Red for 1
        end
    end
    
    colors = [colors; current_colors];
end

%% Step 3: Create the plot (simpler version)
figure('Position', [100, 100, 1200, 800]);
hold on;

% Plot with simple coloring
plot_colors = zeros(length(all_cond), 3);
plot_colors(all_cond == 0, :) = repmat([0 0 1], sum(all_cond == 0), 1); % Blue
plot_colors(all_cond == 1, :) = repmat([1 0 0], sum(all_cond == 1), 1); % Red
plot_colors(all_cond > 1, :) = repmat([0 1 0], sum(all_cond > 1), 1); % Green for other values

scatter(all_x, all_y, 10, plot_colors, 'filled', 'MarkerEdgeAlpha', 0.3, 'MarkerFaceAlpha', 0.3);

% Add labels and title
xlabel('X Coordinate (cm)', 'FontSize', 12);
ylabel('Y Coordinate (cm)', 'FontSize', 12);
title('Normalized Animal Positions Colored by Condition', 'FontSize', 14);

% Add appropriate legend based on what we found
if any(all_cond > 1)
    legend_entries = {'Condition = 0', 'Condition = 1', 'Other conditions'};
    colors_for_legend = {'b', 'r', 'g'};
else
    legend_entries = {'Condition = 0', 'Condition = 1'};
    colors_for_legend = {'b', 'r'};
end

h = zeros(length(legend_entries), 1);
for i = 1:length(legend_entries)
    h(i) = plot(NaN, NaN, [colors_for_legend{i} '.'], 'MarkerSize', 15);
end
legend(h, legend_entries, 'Location', 'best');

% Set equal aspect ratio for proper visualization
axis equal;
grid on;
hold off;

%% Alternative: Plot by individual animals
figure('Position', [100, 100, 1400, 800]);

% Determine grid size for subplots
num_animals = length(var);
cols = ceil(sqrt(num_animals));
rows = ceil(num_animals / cols);

for n = 1:num_animals
    subplot(rows, cols, n);
    
    % Get data for this animal
    current_coords = var(n).NormalizedCoordinates;
    current_cond = double(var(n).cond);
    
    % Create colors
    plot_colors_single = zeros(length(current_cond), 3);
    cond0_idx = current_cond == 0;
    cond1_idx = current_cond == 1;
    plot_colors_single(cond0_idx, :) = repmat([0 0 1], sum(cond0_idx), 1);
    plot_colors_single(cond1_idx, :) = repmat([1 0 0], sum(cond1_idx), 1);
    
    scatter(current_coords(:, 1), current_coords(:, 2), 10, plot_colors_single, 'filled');
    
    % Title with animal info
    title(sprintf('Animal %d: %s', n, var(n).animalmark));
    xlabel('X (cm)');
    ylabel('Y (cm)');
    axis equal;
    grid on;
end

%% Print summary statistics
fprintf('\n=== Data Summary ===\n');
fprintf('Total number of animals: %d\n', length(var));
fprintf('Total number of data points: %d\n', length(all_x));
fprintf('Condition distribution:\n');
unique_conds = unique(all_cond);
for i = 1:length(unique_conds)
    count = sum(all_cond == unique_conds(i));
    percentage = 100 * count / length(all_cond);
    fprintf('  Condition %d: %d points (%.1f%%)\n', unique_conds(i), count, percentage);
end
fprintf('X range: [%.2f, %.2f] cm\n', min(all_x), max(all_x));
fprintf('Y range: [%.2f, %.2f] cm\n', min(all_y), max(all_y));

%% If you want to save the processed data
%% Step 2: Create individual animal subplot grid
num_animals = length(var);

% Determine optimal grid size for readability
if num_animals <= 12
    rows = 3;
    cols = 4;
elseif num_animals <= 24
    rows = 4;
    cols = 6;
elseif num_animals <= 48
    rows = 6;
    cols = 8;
elseif num_animals <= 96
    rows = 8;
    cols = 12;
else
    rows = 10;
    cols = 10;
end

% Create figure for individual animals
figure('Position', [50, 50, 1800, 1000], 'Name', 'Individual Animal Trajectories');
sgtitle('Individual Animal Normalized Trajectories (Color: Condition)', 'FontSize', 16, 'FontWeight', 'bold');

for n = 1:min(num_animals, rows*cols)  % In case we have more than grid can hold
    % Get current subplot position
    subplot(rows, cols, n);
    hold on;
    
    % Extract data for this animal
    current_coords = var(n).NormalizedCoordinates;
    current_cond = var(n).cond;
    
    % Handle different data types for condition
    if islogical(current_cond)
        current_cond = double(current_cond);
    end
    
    % Plot points colored by condition
    cond0_idx = current_cond == 0;
    cond1_idx = current_cond == 1;
    
    % Plot condition 0 points (blue)
    if any(cond0_idx)
        scatter(current_coords(cond0_idx, 1), current_coords(cond0_idx, 2), ...
                8, 'b', 'filled', 'MarkerEdgeAlpha', 0.5, 'MarkerFaceAlpha', 0.5);
    end
    
    % Plot condition 1 points (red)
    if any(cond1_idx)
        scatter(current_coords(cond1_idx, 1), current_coords(cond1_idx, 2), ...
                8, 'r', 'filled', 'MarkerEdgeAlpha', 0.5, 'MarkerFaceAlpha', 0.5);
    end
    
    % Plot other conditions if they exist (green)
    other_idx = ~(cond0_idx | cond1_idx);
    if any(other_idx)
        scatter(current_coords(other_idx, 1), current_coords(other_idx, 2), ...
                8, 'g', 'filled', 'MarkerEdgeAlpha', 0.5, 'MarkerFaceAlpha', 0.5);
    end
    
    % Add title with animal info
    title_str = sprintf('Animal %d\n%s', n, var(n).animalmark);
    title(title_str, 'FontSize', 8);
    
    % Add small text with key info
    info_str = sprintf('Test: %s\nSide: %s\nDefeat: %d', ...
                       var(n).TestStep, ...
                       var(n).CondSide, ...
                       var(n).DefeatStatus);
    text(0.02, 0.98, info_str, 'Units', 'normalized', ...
         'FontSize', 6, 'VerticalAlignment', 'top', 'BackgroundColor', 'w', 'Margin', 1);
    
    % Set axis limits based on all data for consistency
    all_x_all = [];
    all_y_all = [];
    for i = 1:length(var)
        all_x_all = [all_x_all; var(i).NormalizedCoordinates(:, 1)];
        all_y_all = [all_y_all; var(i).NormalizedCoordinates(:, 2)];
    end
    
    % Use consistent axis limits with 5% padding
    x_padding = 0.05 * range(all_x_all);
    y_padding = 0.05 * range(all_y_all);
    xlim([min(all_x_all)-x_padding, max(all_x_all)+x_padding]);
    ylim([min(all_y_all)-y_padding, max(all_y_all)+y_padding]);
    
    % Only show axis labels for outer plots
    if mod(n, cols) == 1  % First column
        ylabel('Y (cm)', 'FontSize', 7);
    end
    if n > (rows-1)*cols  % Last row
        xlabel('X (cm)', 'FontSize', 7);
    end
    
    grid on;
    box on;
    axis equal;
    hold off;
end

% Add a super legend
hL = legend({'Condition 0', 'Condition 1', 'Other'}, ...
           'Orientation', 'horizontal', 'Position', [0.4, 0.02, 0.2, 0.02]);
set(hL, 'FontSize', 10);

%% Step 3: Create aggregated overview plot
figure('Position', [100, 100, 1400, 600]);

% Subplot 1: All points aggregated
subplot(1, 2, 1);
hold on;

% Collect all data for aggregation
all_x = [];
all_y = [];
all_cond = [];

for n = 1:length(var)
    all_x = [all_x; var(n).NormalizedCoordinates(:, 1)];
    all_y = [all_y; var(n).NormalizedCoordinates(:, 2)];
    current_cond = var(n).cond;
    if islogical(current_cond)
        current_cond = double(current_cond);
    end
    all_cond = [all_cond; current_cond];
end

% Plot with color coding
cond0_idx = all_cond == 0;
cond1_idx = all_cond == 1;
other_idx = ~(cond0_idx | cond1_idx);

% Create a density-sensitive alpha (transparency)
alpha0 = min(0.3, 5000/length(all_x));
alpha1 = min(0.3, 5000/length(all_x));
alpha_other = min(0.3, 5000/length(all_x));

if any(cond0_idx)
    scatter(all_x(cond0_idx), all_y(cond0_idx), 10, 'b', ...
            'filled', 'MarkerEdgeAlpha', alpha0, 'MarkerFaceAlpha', alpha0);
end
if any(cond1_idx)
    scatter(all_x(cond1_idx), all_y(cond1_idx), 10, 'r', ...
            'filled', 'MarkerEdgeAlpha', alpha1, 'MarkerFaceAlpha', alpha1);
end
if any(other_idx)
    scatter(all_x(other_idx), all_y(other_idx), 10, 'g', ...
            'filled', 'MarkerEdgeAlpha', alpha_other, 'MarkerFaceAlpha', alpha_other);
end

xlabel('X Coordinate (cm)', 'FontSize', 12);
ylabel('Y Coordinate (cm)', 'FontSize', 12);
title('All Animals Aggregated', 'FontSize', 14);
legend({'Condition 0', 'Condition 1', 'Other'}, 'Location', 'best');
axis equal;
grid on;
hold off;

% Subplot 2: Heatmap density plot
subplot(1, 2, 2);
nbins = 50;
histogram2(all_x, all_y, nbins, 'DisplayStyle', 'tile', 'ShowEmptyBins', 'on');
colorbar;
xlabel('X Coordinate (cm)', 'FontSize', 12);
ylabel('Y Coordinate (cm)', 'FontSize', 12);
title('Position Density Heatmap', 'FontSize', 14);
axis equal;

