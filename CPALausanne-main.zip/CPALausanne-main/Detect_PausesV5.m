%% ========================================================================
%  Mean & Median velocity per chamber (pause-excluded, binned) → Excel
%  Also adds global (all chambers combined) metrics
%  ========================================================================
close all; clc;

cd 'Z:\FAC\FBM\DSB\stzanoul\social_stress\D2c\Pierre-HuguesSTz\CPA Lausanne MetoficoProcessing\Stamatina8\current matlab datasets\extracted data\smoothing movmean 12 frames\VGAT';
% ---------------- USER PARAMETERS ---------------------------------------
tol = 2;                    % Velocity threshold for pause detection (cm/s)
min_pause_frames = 100;     % Minimum consecutive frames to count as pause
frameRate = 25;             % Hz
nTimeBins = 1;              % Number of time bins
outputFile = 'ChamberVelocity_PauseExcluded.xlsx';

% ---------------- LOAD DATA ---------------------------------------------
trajectories = VGAT;
%trajectories = Lausanne1;
%trajectories = FullCPALausanneAnxiety;
% ---------------- INITIALIZE OUTPUT TABLE -------------------------------
out = table();
zones = {'cond', 'uncond', 'corridor'};

% ---------------- MAIN LOOP ---------------------------------------------
for n = 1:numel(trajectories)
    T = trajectories(n);
    
    % Basic checks
    if ~isfield(T, 'velocity') || isempty(T.velocity) || ...
       ~isfield(T, 'cond') || ~isfield(T, 'uncond') || ~isfield(T, 'corridor')
        fprintf('Skipping trajectory %d: missing fields\n', n);
        continue;
    end
    
    
    % CONVERT VELOCITY TO CONSISTENT UNITS (cm/s)
    vel = T.velocity(:);
    
    %use this only if velocity is not moving averaged already 
    % Clean velocity data (with safety fix)
    vel(abs(vel) > 50) = NaN;
    dv = abs(diff(vel));
    sd_dv = nanstd(dv);
    if ~isnan(sd_dv) && sd_dv > 0
        vel([false; dv > 5*sd_dv]) = NaN;
    end
    vel = fillmissing(vel, 'linear');
    vel = movmean(vel, 12);
    
    % Assuming velocity is already in cm/s
    v_cm_per_s = vel;
    
    %% -------- PAUSE DETECTION ------------------------------------------
    is_stopped = abs(v_cm_per_s) < tol;
    
    % Find consecutive stopped frames
    is_stopped_padded = [0; is_stopped; 0];
    d = diff(is_stopped_padded);
    startIdx = find(d == 1);
    endIdx = find(d == -1) - 1;
    
    pause_mask = false(size(is_stopped));
    for k = 1:numel(startIdx)
        if (endIdx(k) - startIdx(k) + 1) >= min_pause_frames
            pause_mask(startIdx(k):endIdx(k)) = true;
        end
    end
    
    % Diagnostic output
    fprintf('Trajectory %d: Total frames: %d, Paused frames: %d (%.1f%%)\n', ...
            n, length(v_cm_per_s), sum(pause_mask), ...
            100*sum(pause_mask)/length(v_cm_per_s));
    
    %% -------- PROPORTIONAL TIME BINS -------------------------------------
    nFrames = numel(v_cm_per_s);
    frameBin = ceil((1:nFrames)' / nFrames * nTimeBins);
    frameBin = min(max(frameBin, 1), nTimeBins);
    
    %% -------- ZONE MASKS -------------------------------------------------
    zoneMask.cond = T.cond(:) > 0.5;
    zoneMask.uncond = T.uncond(:) > 0.5;
    zoneMask.corridor = T.corridor(:) > 0.5;
    
    % Check zone assignments sum to 1 (or close) - diagnostic
    total_zone = zoneMask.cond + zoneMask.uncond + zoneMask.corridor;
    if any(total_zone > 1.1)  % Allow small overlap due to thresholding
        fprintf('  Warning: Zone overlap detected in trajectory %d\n', n);
    end
    
    % -------- GLOBAL MASK (any zone) -------------------------------------
    global_mask = zoneMask.cond | zoneMask.uncond | zoneMask.corridor;
    
    %% -------- COMPUTE PER BIN × ZONE -------------------------------------
    for b = 1:nTimeBins
        inBin = (frameBin == b);
        
        % ========== PER‑ZONE METRICS (original) ==========
        for z = 1:numel(zones)
            zname = zones{z};
            zmask = zoneMask.(zname);
            
            % Combine all criteria for velocity calculations
            valid = inBin & zmask & ~pause_mask & ~isnan(v_cm_per_s);
            
            % Calculate total frames in zone (for pause percentage)
            total_zone_frames = sum(inBin & zmask);
            
            % Calculate paused frames in zone
            paused_in_zone = sum(inBin & zmask & pause_mask);
            
            % Calculate percentage paused in zone
            if total_zone_frames > 0
                percent_paused = 100 * paused_in_zone / total_zone_frames;
            else
                percent_paused = NaN;
            end
            
            if sum(valid) > 0
                valid_velocities = v_cm_per_s(valid);
                meanVel = mean(valid_velocities);
                medianVel = median(valid_velocities);
                nValidFrames = sum(valid);
                
                % Diagnostic: suspicious values
                if meanVel > 100
                    fprintf('  Warning: High mean velocity (%.1f cm/s) in %s, bin %d\n', ...
                            meanVel, zname, b);
                end
            else
                meanVel = NaN;
                medianVel = NaN;
                nValidFrames = 0;
            end
            
            %% -------- APPEND ROW (per zone) -----------------------------
            newRow = table( ...
                string(T.animalmark), ...
                T.DefeatStatus, ...
                string(T.TestStep), ...
                b, ...
                string(zname), ...
                meanVel, ...
                medianVel, ...
                nValidFrames, ...
                percent_paused, ...
                paused_in_zone, ...
                total_zone_frames, ...
                'VariableNames', { ...
                    'Animal', ...
                    'DefeatStatus', ...
                    'TestStep', ...
                    'TimeBin', ...
                    'Zone', ...
                    'MeanVelocity', ...
                    'MedianVelocity', ...
                    'NValidFrames', ...
                    'PercentPaused', ...
                    'PausedFrames', ...
                    'TotalZoneFrames'} );
            
            out = [out; newRow];
        end
        
        % ========== GLOBAL METRICS (all chambers combined) ==========
        % Use the global_mask (any zone) instead of a single zone
        valid_global = inBin & global_mask & ~pause_mask & ~isnan(v_cm_per_s);
        
        total_global_frames = sum(inBin & global_mask);
        paused_global = sum(inBin & global_mask & pause_mask);
        
        if total_global_frames > 0
            percent_paused_global = 100 * paused_global / total_global_frames;
        else
            percent_paused_global = NaN;
        end
        
        if sum(valid_global) > 0
            valid_velocities_global = v_cm_per_s(valid_global);
            meanVel_global = mean(valid_velocities_global);
            medianVel_global = median(valid_velocities_global);
            nValidFrames_global = sum(valid_global);
            
            if meanVel_global > 100
                fprintf('  Warning: High global mean velocity (%.1f cm/s) in bin %d\n', ...
                        meanVel_global, b);
            end
        else
            meanVel_global = NaN;
            medianVel_global = NaN;
            nValidFrames_global = 0;
        end
        
        % Append the global row with Zone = 'global'
        globalRow = table( ...
            string(T.animalmark), ...
            T.DefeatStatus, ...
            string(T.TestStep), ...
            b, ...
            "global", ...                     % Zone label for global
            meanVel_global, ...
            medianVel_global, ...
            nValidFrames_global, ...
            percent_paused_global, ...
            paused_global, ...
            total_global_frames, ...
            'VariableNames', { ...
                'Animal', ...
                'DefeatStatus', ...
                'TestStep', ...
                'TimeBin', ...
                'Zone', ...
                'MeanVelocity', ...
                'MedianVelocity', ...
                'NValidFrames', ...
                'PercentPaused', ...
                'PausedFrames', ...
                'TotalZoneFrames'} );
        
        out = [out; globalRow];
        
    end % time bin loop
end % trajectory loop

% ---------------- SUMMARY STATISTICS (using all zones present) ----------
fprintf('\n=== Summary Statistics ===\n');
fprintf('Total rows: %d\n', height(out));

% Get unique zone names (includes 'cond','uncond','corridor','global')
uniqueZones = unique(out.Zone);
fprintf('Mean velocities by zone:\n');
for i = 1:numel(uniqueZones)
    z = uniqueZones{i};
    zone_data = out(strcmp(out.Zone, z), :);
    fprintf('  %s: %.3f ± %.3f cm/s (n=%d)\n', ...
            z, nanmean(zone_data.MeanVelocity), ...
            nanstd(zone_data.MeanVelocity), ...
            sum(~isnan(zone_data.MeanVelocity)));
end

fprintf('\nPause percentages by zone:\n');
for i = 1:numel(uniqueZones)
    z = uniqueZones{i};
    zone_data = out(strcmp(out.Zone, z), :);
    fprintf('  %s: %.1f ± %.1f%% paused (n=%d)\n', ...
            z, nanmean(zone_data.PercentPaused), ...
            nanstd(zone_data.PercentPaused), ...
            sum(~isnan(zone_data.PercentPaused)));
end

% ---------------- WRITE EXCEL -------------------------------------------
writetable(out, outputFile);
fprintf('\n✔ Excel file written: %s\n', outputFile);

% Create a summary table for velocities
summaryVelocity = grpstats(out(:, {'Zone', 'MeanVelocity', 'MedianVelocity'}), ...
                       'Zone', {'mean', 'std', 'numel'}, ...
                       'DataVars', {'MeanVelocity', 'MedianVelocity'});
writetable(summaryVelocity, 'Velocity_Summary_Stats.xlsx');
fprintf('✔ Velocity summary statistics written to: Velocity_Summary_Stats.xlsx\n');

% Create a summary table for pause percentages
summaryPause = grpstats(out(:, {'Zone', 'PercentPaused'}), ...
                       'Zone', {'mean', 'std', 'numel'}, ...
                       'DataVars', {'PercentPaused'});
writetable(summaryPause, 'Pause_Percentage_Summary.xlsx');
fprintf('✔ Pause percentage summary written to: Pause_Percentage_Summary.xlsx\n');