close all
clc
cd 'Z:\FAC\FBM\DSB\stzanoul\social_stress\D2c\Pierre-HuguesSTz\CPA Lausanne MetoficoProcessing\Stamatina8\current matlab datasets\extracted data\smoothing movmean 12 frames\VGAT'
% Main execution with updated structure
%var = FullCPALausanneAnxiety;
var = VGAT;
%var=Lausanne1;
[final_table, updated_structure] = TransitionVelocityTableExtraction(var);

% Update in the original structure
for n = 1:size(var, 2)
    var(n).transitions = updated_structure(n).transitions;
    var(n).transition_stats = updated_structure(n).transition_stats;
    var(n).transitions_detailed = updated_structure(n).transitions_detailed;
end

function [final_table, updated_structure] = TransitionVelocityTableExtraction(var)
% TransitionVelocityTableExtraction processes velocity transitions and plots/export data.
% Input:
% - var: Struct array with trial data and logical state vectors
% Output:
% - final_table: Table with transition counts and mean peak velocities
% - updated_structure: Original structure with recalculated transition fields

% Parameters
velocity_col = 14;  % Column containing velocity data
window_half = 12;  % Window for velocity segment extraction (±0.85s at 30Hz for 51 frames)
num_bins = 1;      % Number of temporal bins
fps = 25;          % Frames per second (for time conversion)

% Initialize table for final output
final_table = table();

% Define all transition types (simple zone changes)
all_transition_types = {
    'cond_exit', 'cond_entrance', ...
    'uncond_exit', 'uncond_entrance'
    };

% Process each trial
for n = 1:numel(var)
    % Extract trial data
    trial = var(n);
    
    % Extract Animal ID from animalmark field
    animal_id = str2double(trial.animalmark);
    if isnan(animal_id)
        animal_id = trial.animalmark;
    end
    
    % Extract DefeatStatus
    defeat_status = trial.DefeatStatus;
    
    % Extract TestStep
    if ischar(trial.TestStep)
        test_step = string(trial.TestStep);
    else
        test_step = string(trial.TestStep);
    end
    
    % Get velocity data
    vel = trial.velocity(:,1);
    
    %use this only if velocity is not moving averaged already 
    % Clean velocity data
    vel(abs(vel) > 50) = NaN;
    dv = abs(diff(vel));
    sd_dv = nanstd(dv);
    if ~isnan(sd_dv) && sd_dv > 0
        vel([false; dv > 5*sd_dv]) = NaN;
    end
    vel = fillmissing(vel, 'linear');
    vel = movmean(vel, 12);
    
    N = length(vel);
    
    % Clean logical vectors
    corridor_vec = logical(fillmissing(trial.corridor, 'constant', 0));
    cond_vec = logical(fillmissing(trial.cond, 'constant', 0));
    uncond_vec = logical(fillmissing(trial.uncond, 'constant', 0));
    
    % Create temporal bins
    bin_edges = round(linspace(1, N, num_bins + 1));
    
    % Detect and categorize transitions (simple zone changes)
    [cond_exit, cond_entrance, uncond_exit, uncond_entrance, all_transitions] = ...
        detect_simple_transitions(corridor_vec, cond_vec, uncond_vec, N);
    
    % Store all transition types with their labels and data
    transition_types = {
        'cond_exit', 'cond_entrance', ...
        'uncond_exit', 'uncond_entrance'
        };
    
    transition_data = {
        cond_exit, cond_entrance, ...
        uncond_exit, uncond_entrance
        };
    
    % Create new transitions structures (no behavior fields)
    [new_transitions, new_transitions_detailed, new_transition_stats] = ...
        create_simple_transition_structures(vel, all_transitions, ...
        cond_exit, cond_entrance, uncond_exit, uncond_entrance, window_half);
    
    % Update the structure with new transition fields
    var(n).transitions = new_transitions;
    var(n).transitions_detailed = new_transitions_detailed;
    var(n).transition_stats = new_transition_stats;
    
    % Create a matrix to store metrics for each transition type in each bin
    peak_velocities = cell(num_bins, length(transition_types));
    median_velocities = cell(num_bins, length(transition_types));
    auc_values = cell(num_bins, length(transition_types));
    transition_counts = zeros(num_bins, length(transition_types));
    
    % First pass: collect metrics for each transition in each bin
    if ~isempty(new_transitions_detailed)
        % Convert transitions_detailed to table for easier processing
        trans_detailed_table = struct2table(new_transitions_detailed);
        
        for t_idx = 1:length(transition_types)
            trans_type = transition_types{t_idx};
            
            % Find all transitions of this type
            trans_idx = find(strcmp(trans_detailed_table.Type, trans_type));
            
            for i = 1:length(trans_idx)
                trans = new_transitions_detailed(trans_idx(i));
                
                % Determine which bin this transition belongs to
                for bin = 1:num_bins
                    if trans.CenterFrame >= bin_edges(bin) && trans.CenterFrame < bin_edges(bin+1)
                        % Store peak velocity
                        if isempty(peak_velocities{bin, t_idx})
                            peak_velocities{bin, t_idx} = trans.PeakVelocity;
                            median_velocities{bin, t_idx} = trans.MedianVelocity;
                            auc_values{bin, t_idx} = trans.AUC;
                        else
                            peak_velocities{bin, t_idx} = [peak_velocities{bin, t_idx}; trans.PeakVelocity];
                            median_velocities{bin, t_idx} = [median_velocities{bin, t_idx}; trans.MedianVelocity];
                            auc_values{bin, t_idx} = [auc_values{bin, t_idx}; trans.AUC];
                        end
                        
                        % Increment count
                        transition_counts(bin, t_idx) = transition_counts(bin, t_idx) + 1;
                        break;
                    end
                end
            end
        end
    end
    
    % Second pass: create table with ALL combinations (even zero counts)
    trial_rows = table();
    
    for bin = 1:num_bins
        for t_idx = 1:length(transition_types)
            trans_type = transition_types{t_idx};
            trans_count = transition_counts(bin, t_idx);
            
            % Calculate mean metrics for this bin and transition type
            if trans_count > 0 && ~isempty(peak_velocities{bin, t_idx})
                mean_peak_vel = mean(peak_velocities{bin, t_idx});
                mean_median_vel = mean(median_velocities{bin, t_idx});
                mean_auc = mean(auc_values{bin, t_idx});
            else
                mean_peak_vel = NaN; % No transitions, so no mean
                mean_median_vel = NaN;
                mean_auc = NaN;
            end
            
            % Create row with all required columns
            row = table(...
                animal_id, defeat_status, test_step, bin, {trans_type}, ...
                trans_count, mean_peak_vel, mean_median_vel, mean_auc, ...
                'VariableNames', {...
                'Animal', 'DefeatStatus', 'TestStep', 'TimeBin', 'Zone', ...
                'TransitionCount', 'MeanPeakVelocity', 'MeanMedianVelocity', 'MeanAUC'...
                });
            
            trial_rows = [trial_rows; row];
        end
    end
    
    % Add this trial's data to final table
    final_table = [final_table; trial_rows];
end

% Ensure consistent data types
final_table.Animal = double(final_table.Animal);
final_table.DefeatStatus = double(final_table.DefeatStatus);
final_table.TimeBin = double(final_table.TimeBin);
final_table.TransitionCount = double(final_table.TransitionCount);
final_table.MeanPeakVelocity = double(final_table.MeanPeakVelocity);
final_table.MeanMedianVelocity = double(final_table.MeanMedianVelocity);
final_table.MeanAUC = double(final_table.MeanAUC);

if iscell(final_table.TestStep)
    final_table.TestStep = string(final_table.TestStep);
end

if iscell(final_table.Zone)
    final_table.Zone = string(final_table.Zone);
end

final_table = sortrows(final_table, {'Animal', 'DefeatStatus', 'TestStep', 'TimeBin', 'Zone'});

% Create output directory
output_dir = 'Transition_Data_Export';
if ~exist(output_dir, 'dir')
    mkdir(output_dir);
end

% Export to Excel
output_filename = fullfile(output_dir, 'Transition_Summary.xlsx');
writetable(final_table, output_filename, 'Sheet', 'Detailed_Data');

fprintf('Data exported to: %s\n', output_filename);
fprintf('Total rows: %d\n', height(final_table));

% Create summary sheets
summary_table = final_table(:, {'Animal', 'DefeatStatus', 'TestStep', 'TimeBin', 'Zone', ...
    'TransitionCount', 'MeanPeakVelocity', 'MeanMedianVelocity', 'MeanAUC'});
create_excel_summaries(summary_table, output_filename);

% Generate additional reports
generate_reports(summary_table, output_dir);

% Return updated structure
updated_structure = var;

end

%% --- Helper Function: Detect Simple Transitions ---
function [cond_exit, cond_entrance, uncond_exit, uncond_entrance, all_transitions] = ...
    detect_simple_transitions(corridor, cond, uncond, N)

% Initialize outputs
cond_exit = [];
cond_entrance = [];
uncond_exit = [];
uncond_entrance = [];
all_transitions = [];

% Find all transitions between zones
for i = 2:N
    % Check for zone changes
    if corridor(i-1) && cond(i)  % corridor -> cond
        all_transitions = [all_transitions; struct('frame', i, 'from', 'corridor', 'to', 'cond')];
        cond_entrance = [cond_entrance; i];
    elseif cond(i-1) && corridor(i)  % cond -> corridor
        all_transitions = [all_transitions; struct('frame', i, 'from', 'cond', 'to', 'corridor')];
        cond_exit = [cond_exit; i];
    elseif corridor(i-1) && uncond(i)  % corridor -> uncond
        all_transitions = [all_transitions; struct('frame', i, 'from', 'corridor', 'to', 'uncond')];
        uncond_entrance = [uncond_entrance; i];
    elseif uncond(i-1) && corridor(i)  % uncond -> corridor
        all_transitions = [all_transitions; struct('frame', i, 'from', 'uncond', 'to', 'corridor')];
        uncond_exit = [uncond_exit; i];
    end
end

% Remove duplicates and sort
cond_exit = unique(cond_exit);
cond_entrance = unique(cond_entrance);
uncond_exit = unique(uncond_exit);
uncond_entrance = unique(uncond_entrance);
end

%% --- Helper Function: Create Simple Transition Structures ---
function [transitions, transitions_detailed, transition_stats] = ...
    create_simple_transition_structures(vel, all_transitions, ...
    cond_exit, cond_entrance, uncond_exit, uncond_entrance, window_half)

% Initialize structures
transitions = struct();
transitions_detailed = struct();
transition_stats = struct();

% Create transitions_detailed (all transitions)
for i = 1:length(all_transitions)
    trans = all_transitions(i);
    
    % Determine transition type
    if ismember(trans.frame, cond_exit)
        trans_type = 'cond_exit';
        full_type = 'conditioned_exit';
    elseif ismember(trans.frame, cond_entrance)
        trans_type = 'cond_entrance';
        full_type = 'conditioned_entrance';
    elseif ismember(trans.frame, uncond_exit)
        trans_type = 'uncond_exit';
        full_type = 'unconditioned_exit';
    elseif ismember(trans.frame, uncond_entrance)
        trans_type = 'uncond_entrance';
        full_type = 'unconditioned_entrance';
    else
        trans_type = 'unknown';
        full_type = 'unknown_transition';
    end
    
    % Extract velocity segment
    start_frame = max(1, trans.frame - window_half);
    end_frame = min(length(vel), trans.frame + window_half);
    velocity_segment = vel(start_frame:end_frame);
    time_vector = (0:(length(velocity_segment)-1)) / (2*window_half); % Normalized time
    
    % Calculate metrics
    peak_velocity = max(velocity_segment);
    median_velocity = median(velocity_segment);
    
    % Calculate Area Under the Curve (AUC) using trapezoidal integration
    % Note: We take absolute value to get total area regardless of direction
    auc_value = trapz(time_vector, abs(velocity_segment));
    
    % Create transitions_detailed entry (no behavior fields)
    transitions_detailed(i).Type = trans_type;
    transitions_detailed(i).CenterFrame = trans.frame;
    transitions_detailed(i).VelocitySegment = velocity_segment;
    transitions_detailed(i).TimeVector = time_vector;
    transitions_detailed(i).PeakVelocity = peak_velocity;
    transitions_detailed(i).MedianVelocity = median_velocity;
    transitions_detailed(i).AUC = auc_value;
    transitions_detailed(i).FromZone = zone_to_number(trans.from);
    transitions_detailed(i).ToZone = zone_to_number(trans.to);
    transitions_detailed(i).FullTransitionType = full_type;
    transitions_detailed(i).StartFrame = start_frame;
    transitions_detailed(i).EndFrame = end_frame;
end

% Create transitions structure (same as detailed but without extra processing)
transitions = transitions_detailed;

% Create transition_stats
transition_stats.n_cond_exit = length(cond_exit);
transition_stats.n_cond_entrance = length(cond_entrance);
transition_stats.n_uncond_exit = length(uncond_exit);
transition_stats.n_uncond_entrance = length(uncond_entrance);
transition_stats.total_transitions = transition_stats.n_cond_exit + ...
    transition_stats.n_cond_entrance + transition_stats.n_uncond_exit + ...
    transition_stats.n_uncond_entrance;

% Calculate mean values for each transition type
transition_stats = calculate_simple_transition_statistics(transition_stats, transitions_detailed);
end

%% --- Helper Function: Calculate Simple Transition Statistics ---
function stats = calculate_simple_transition_statistics(stats, transitions_detailed)
% Helper function to calculate mean statistics for each transition type

% Initialize arrays for each statistic
cond_exit_peaks = [];
cond_exit_medians = [];
cond_exit_aucs = [];

cond_entrance_peaks = [];
cond_entrance_medians = [];
cond_entrance_aucs = [];

uncond_exit_peaks = [];
uncond_exit_medians = [];
uncond_exit_aucs = [];

uncond_entrance_peaks = [];
uncond_entrance_medians = [];
uncond_entrance_aucs = [];

% Extract data from transitions_detailed structure
if ~isempty(transitions_detailed)
    for i = 1:length(transitions_detailed)
        trans = transitions_detailed(i);
        
        switch trans.Type
            case 'cond_exit'
                cond_exit_peaks = [cond_exit_peaks; trans.PeakVelocity];
                cond_exit_medians = [cond_exit_medians; trans.MedianVelocity];
                cond_exit_aucs = [cond_exit_aucs; trans.AUC];
                
            case 'cond_entrance'
                cond_entrance_peaks = [cond_entrance_peaks; trans.PeakVelocity];
                cond_entrance_medians = [cond_entrance_medians; trans.MedianVelocity];
                cond_entrance_aucs = [cond_entrance_aucs; trans.AUC];
                
            case 'uncond_exit'
                uncond_exit_peaks = [uncond_exit_peaks; trans.PeakVelocity];
                uncond_exit_medians = [uncond_exit_medians; trans.MedianVelocity];
                uncond_exit_aucs = [uncond_exit_aucs; trans.AUC];
                
            case 'uncond_entrance'
                uncond_entrance_peaks = [uncond_entrance_peaks; trans.PeakVelocity];
                uncond_entrance_medians = [uncond_entrance_medians; trans.MedianVelocity];
                uncond_entrance_aucs = [uncond_entrance_aucs; trans.AUC];
        end
    end
end

% Calculate means
if ~isempty(cond_exit_peaks)
    stats.mean_peak_cond_exit = mean(cond_exit_peaks);
    stats.mean_median_cond_exit = mean(cond_exit_medians);
    stats.mean_auc_cond_exit = mean(cond_exit_aucs);
else
    stats.mean_peak_cond_exit = NaN;
    stats.mean_median_cond_exit = NaN;
    stats.mean_auc_cond_exit = NaN;
end

if ~isempty(cond_entrance_peaks)
    stats.mean_peak_cond_entrance = mean(cond_entrance_peaks);
    stats.mean_median_cond_entrance = mean(cond_entrance_medians);
    stats.mean_auc_cond_entrance = mean(cond_entrance_aucs);
else
    stats.mean_peak_cond_entrance = NaN;
    stats.mean_median_cond_entrance = NaN;
    stats.mean_auc_cond_entrance = NaN;
end

if ~isempty(uncond_exit_peaks)
    stats.mean_peak_uncond_exit = mean(uncond_exit_peaks);
    stats.mean_median_uncond_exit = mean(uncond_exit_medians);
    stats.mean_auc_uncond_exit = mean(uncond_exit_aucs);
else
    stats.mean_peak_uncond_exit = NaN;
    stats.mean_median_uncond_exit = NaN;
    stats.mean_auc_uncond_exit = NaN;
end

if ~isempty(uncond_entrance_peaks)
    stats.mean_peak_uncond_entrance = mean(uncond_entrance_peaks);
    stats.mean_median_uncond_entrance = mean(uncond_entrance_medians);
    stats.mean_auc_uncond_entrance = mean(uncond_entrance_aucs);
else
    stats.mean_peak_uncond_entrance = NaN;
    stats.mean_median_uncond_entrance = NaN;
    stats.mean_auc_uncond_entrance = NaN;
end

% Calculate ratios
if stats.mean_peak_uncond_exit > 0
    stats.cond_to_uncond_exit_peak_ratio = stats.mean_peak_cond_exit / stats.mean_peak_uncond_exit;
else
    stats.cond_to_uncond_exit_peak_ratio = NaN;
end

if stats.mean_peak_uncond_entrance > 0
    stats.cond_to_uncond_entrance_peak_ratio = stats.mean_peak_cond_entrance / stats.mean_peak_uncond_entrance;
else
    stats.cond_to_uncond_entrance_peak_ratio = NaN;
end

% Calculate exit-to-entrance ratios
if stats.mean_peak_cond_entrance > 0
    stats.cond_exit_to_entrance_peak_ratio = stats.mean_peak_cond_exit / stats.mean_peak_cond_entrance;
else
    stats.cond_exit_to_entrance_peak_ratio = NaN;
end

if stats.mean_peak_uncond_entrance > 0
    stats.uncond_exit_to_entrance_peak_ratio = stats.mean_peak_uncond_exit / stats.mean_peak_uncond_entrance;
else
    stats.uncond_exit_to_entrance_peak_ratio = NaN;
end
end

%% --- Helper Function: Zone to Number Conversion ---
function num = zone_to_number(zone_str)
switch zone_str
    case 'cond'
        num = 1;
    case 'uncond'
        num = 2;
    case 'corridor'
        num = 3;
    otherwise
        num = 0;
end
end

%% --- Helper Function: Create Excel Summaries ---
function create_excel_summaries(final_table, excel_filename)
if ~isempty(final_table)
    % Create summary with all metrics
    animal_groups = findgroups(final_table.Animal, final_table.TestStep);
    total_counts = splitapply(@sum, final_table.TransitionCount, animal_groups);
    mean_peak = splitapply(@nanmean, final_table.MeanPeakVelocity, animal_groups);
    mean_median = splitapply(@nanmean, final_table.MeanMedianVelocity, animal_groups);
    mean_auc = splitapply(@nanmean, final_table.MeanAUC, animal_groups);
    
    [unique_animals, unique_steps] = splitapply(@(x,y) deal(x(1), y(1)), ...
        final_table.Animal, final_table.TestStep, animal_groups);
    
    animal_summary = table(unique_animals, unique_steps, total_counts, ...
        mean_peak, mean_median, mean_auc, ...
        'VariableNames', {'Animal', 'TestStep', 'TotalTransitions', ...
        'MeanPeakVelocity', 'MeanMedianVelocity', 'MeanAUC'});
    
    step_groups = findgroups(final_table.TestStep, final_table.Zone);
    step_counts = splitapply(@sum, final_table.TransitionCount, step_groups);
    step_mean_peak = splitapply(@nanmean, final_table.MeanPeakVelocity, step_groups);
    step_mean_median = splitapply(@nanmean, final_table.MeanMedianVelocity, step_groups);
    step_mean_auc = splitapply(@nanmean, final_table.MeanAUC, step_groups);
    
    [unique_steps2, unique_zones] = splitapply(@(x,y) deal(x(1), y(1)), ...
        final_table.TestStep, final_table.Zone, step_groups);
    
    step_summary = table(unique_steps2, unique_zones, step_counts, ...
        step_mean_peak, step_mean_median, step_mean_auc, ...
        'VariableNames', {'TestStep', 'Zone', 'TotalTransitions', ...
        'MeanPeakVelocity', 'MeanMedianVelocity', 'MeanAUC'});
    
    defeat_groups = findgroups(final_table.DefeatStatus, final_table.Zone);
    defeat_counts = splitapply(@sum, final_table.TransitionCount, defeat_groups);
    defeat_mean_peak = splitapply(@nanmean, final_table.MeanPeakVelocity, defeat_groups);
    defeat_mean_median = splitapply(@nanmean, final_table.MeanMedianVelocity, defeat_groups);
    defeat_mean_auc = splitapply(@nanmean, final_table.MeanAUC, defeat_groups);
    
    [unique_defeats, unique_zones2] = splitapply(@(x,y) deal(x(1), y(1)), ...
        final_table.DefeatStatus, final_table.Zone, defeat_groups);
    
    defeat_summary = table(unique_defeats, unique_zones2, defeat_counts, ...
        defeat_mean_peak, defeat_mean_median, defeat_mean_auc, ...
        'VariableNames', {'DefeatStatus', 'Zone', 'TotalTransitions', ...
        'MeanPeakVelocity', 'MeanMedianVelocity', 'MeanAUC'});
    
    writetable(animal_summary, excel_filename, 'Sheet', 'Summary_Animal_TestStep');
    writetable(step_summary, excel_filename, 'Sheet', 'Summary_TestStep_Zone');
    writetable(defeat_summary, excel_filename, 'Sheet', 'Summary_Defeat_Zone');
    
    fprintf('Added summary sheets to Excel file.\n');
end
end

%% --- Helper Function: Generate Reports ---
function generate_reports(summary_table, output_dir)
fprintf('\n=== Summary Statistics ===\n');
fprintf('Total transitions: %d\n', sum(summary_table.TransitionCount));

fprintf('\nTransitions by TestStep and Zone:\n');
step_zone_summary = groupsummary(summary_table, {'TestStep', 'Zone'}, 'sum', 'TransitionCount');
disp(step_zone_summary(:, {'TestStep', 'Zone', 'sum_TransitionCount'}));

fprintf('\n=== Velocity Metrics by TestStep and Zone ===\n');
% Calculate mean of means for each group
teststep_zone_groups = findgroups(summary_table.TestStep, summary_table.Zone);
mean_peak_by_group = splitapply(@nanmean, summary_table.MeanPeakVelocity, teststep_zone_groups);
mean_median_by_group = splitapply(@nanmean, summary_table.MeanMedianVelocity, teststep_zone_groups);
mean_auc_by_group = splitapply(@nanmean, summary_table.MeanAUC, teststep_zone_groups);

[unique_teststeps, unique_zones] = splitapply(@(x,y) deal(x(1), y(1)), ...
    summary_table.TestStep, summary_table.Zone, teststep_zone_groups);

velocity_metrics_summary = table(unique_teststeps, unique_zones, ...
    mean_peak_by_group, mean_median_by_group, mean_auc_by_group, ...
    'VariableNames', {'TestStep', 'Zone', 'MeanPeakVelocity', ...
    'MeanMedianVelocity', 'MeanAUC'});
disp(velocity_metrics_summary);

fprintf('\n=== Transitions by Animal and TestStep ===\n');
animal_step_summary = groupsummary(summary_table, {'Animal', 'TestStep'}, 'sum', 'TransitionCount');
disp(animal_step_summary(:, {'Animal', 'TestStep', 'sum_TransitionCount'}));

fprintf('\n=== Transitions by Zone Category ===\n');
zone_categories = cell(size(summary_table.Zone));
for i = 1:length(zone_categories)
    if contains(summary_table.Zone(i), 'cond_')
        zone_categories{i} = 'cond';
    else
        zone_categories{i} = 'uncond';
    end
end

temp_table = table(zone_categories, summary_table.TransitionCount, ...
    summary_table.MeanPeakVelocity, summary_table.MeanMedianVelocity, summary_table.MeanAUC, ...
    'VariableNames', {'ZoneCategory', 'TransitionCount', ...
    'MeanPeakVelocity', 'MeanMedianVelocity', 'MeanAUC'});
zone_category_summary = groupsummary(temp_table, 'ZoneCategory', ...
    {'sum', 'mean'}, {'TransitionCount', 'MeanPeakVelocity', 'MeanMedianVelocity', 'MeanAUC'});
disp(zone_category_summary);

fprintf('\nCreating pivoted tables...\n');
create_pivoted_tables(summary_table, output_dir);
end

%% --- Helper Function: Create Pivoted Tables ---
function create_pivoted_tables(summary_table, output_dir)
animals = unique(summary_table.Animal);
teststeps = unique(summary_table.TestStep);
timebins = unique(summary_table.TimeBin);
zones = unique(summary_table.Zone);

% Create pivoted data for transition counts
pivoted_counts = [];
pivoted_peak = [];
pivoted_median = [];
pivoted_auc = [];

for a = 1:length(animals)
    animal = animals(a);
    for ts = 1:length(teststeps)
        teststep = teststeps(ts);
        for tb = 1:length(timebins)
            timebin = timebins(tb);
            
            animal_rows = summary_table(summary_table.Animal == animal, :);
            if ~isempty(animal_rows)
                defeat_status = animal_rows.DefeatStatus(1);
            else
                defeat_status = NaN;
            end
            
            % Create row for counts
            row_counts = table();
            row_counts.Animal = animal;
            row_counts.DefeatStatus = defeat_status;
            row_counts.TestStep = teststep;
            row_counts.TimeBin = timebin;
            
            % Create rows for velocity metrics
            row_peak = row_counts;
            row_median = row_counts;
            row_auc = row_counts;
            
            for z = 1:length(zones)
                zone = zones(z);
                mask = (summary_table.Animal == animal & ...
                    summary_table.TestStep == teststep & ...
                    summary_table.TimeBin == timebin & ...
                    summary_table.Zone == zone);
                
                % Count
                count = sum(summary_table.TransitionCount(mask));
                row_counts.(char(zone)) = count;
                
                % Velocity metrics (take mean if multiple entries)
                if any(mask)
                    row_peak.(char(zone)) = nanmean(summary_table.MeanPeakVelocity(mask));
                    row_median.(char(zone)) = nanmean(summary_table.MeanMedianVelocity(mask));
                    row_auc.(char(zone)) = nanmean(summary_table.MeanAUC(mask));
                else
                    row_peak.(char(zone)) = NaN;
                    row_median.(char(zone)) = NaN;
                    row_auc.(char(zone)) = NaN;
                end
            end
            
            pivoted_counts = [pivoted_counts; row_counts];
            pivoted_peak = [pivoted_peak; row_peak];
            pivoted_median = [pivoted_median; row_median];
            pivoted_auc = [pivoted_auc; row_auc];
        end
    end
end

% Create pivoted summary (aggregated across time bins)
pivoted_counts_summary = [];
pivoted_peak_summary = [];
pivoted_median_summary = [];
pivoted_auc_summary = [];

for a = 1:length(animals)
    animal = animals(a);
    for ts = 1:length(teststeps)
        teststep = teststeps(ts);
        
        animal_rows = summary_table(summary_table.Animal == animal, :);
        if ~isempty(animal_rows)
            defeat_status = animal_rows.DefeatStatus(1);
        else
            defeat_status = NaN;
        end
        
        % Create rows
        row_counts = table();
        row_counts.Animal = animal;
        row_counts.DefeatStatus = defeat_status;
        row_counts.TestStep = teststep;
        
        row_peak = row_counts;
        row_median = row_counts;
        row_auc = row_counts;
        
        for z = 1:length(zones)
            zone = zones(z);
            mask = (summary_table.Animal == animal & ...
                summary_table.TestStep == teststep & ...
                summary_table.Zone == zone);
            
            % Count
            count = sum(summary_table.TransitionCount(mask));
            row_counts.(char(zone)) = count;
            
            % Velocity metrics
            if any(mask)
                row_peak.(char(zone)) = nanmean(summary_table.MeanPeakVelocity(mask));
                row_median.(char(zone)) = nanmean(summary_table.MeanMedianVelocity(mask));
                row_auc.(char(zone)) = nanmean(summary_table.MeanAUC(mask));
            else
                row_peak.(char(zone)) = NaN;
                row_median.(char(zone)) = NaN;
                row_auc.(char(zone)) = NaN;
            end
        end
        
        pivoted_counts_summary = [pivoted_counts_summary; row_counts];
        pivoted_peak_summary = [pivoted_peak_summary; row_peak];
        pivoted_median_summary = [pivoted_median_summary; row_median];
        pivoted_auc_summary = [pivoted_auc_summary; row_auc];
    end
end

% Save to Excel with multiple sheets
pivoted_filename = fullfile(output_dir, 'Pivoted_By_TimeBin.xlsx');
writetable(pivoted_counts, pivoted_filename, 'Sheet', 'Transition_Counts');
writetable(pivoted_peak, pivoted_filename, 'Sheet', 'Peak_Velocity');
writetable(pivoted_median, pivoted_filename, 'Sheet', 'Median_Velocity');
writetable(pivoted_auc, pivoted_filename, 'Sheet', 'Velocity_AUC');

writetable(pivoted_counts_summary, pivoted_filename, 'Sheet', 'Summary_Counts');
writetable(pivoted_peak_summary, pivoted_filename, 'Sheet', 'Summary_Peak');
writetable(pivoted_median_summary, pivoted_filename, 'Sheet', 'Summary_Median');
writetable(pivoted_auc_summary, pivoted_filename, 'Sheet', 'Summary_AUC');

fprintf('Pivoted tables exported to: %s\n', pivoted_filename);
end