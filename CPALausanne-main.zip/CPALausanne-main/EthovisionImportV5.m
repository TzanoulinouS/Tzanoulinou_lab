FullCPALausanne1=importTrajectoryData()
%% adding annotations
for n=1:numel(FullCPALausanne1);
    
   FullCPALausanne1(n).TestStep = FullCPALausanne1(n).fullmetadata{36, 2};
   
   FullCPALausanne1(n).Condition = FullCPALausanne1(n).fullmetadata{37, 2};
if strcmp(FullCPALausanne1(n).fullmetadata{37, 2}, 'DREADDGI')
    FullCPALausanne1(n).DefeatStatus = 1;
else
    FullCPALausanne1(n).DefeatStatus = 0;
end

end


%% --- Add Condition Pattern from External File ---
%it requires an excel file with two columns one for animal number one with
%the conditioned side pattern
% Let user select condition file
%var=FullCPALausanne1;
% --- Add Condition Pattern and Side from External File ---
% Let user select condition file
[condFile, condPath] = uigetfile({'*.xlsx;*.xls;*.csv;*.txt', ...
                                  'Condition files (*.xlsx, *.xls, *.csv, *.txt)'}, ...
                                  'Select condition file');
if isequal(condFile, 0)
    warning('No file selected. Skipping condition pattern and side assignment.');
    return;
end

% Read condition file
fullCondPath = fullfile(condPath, condFile);
try
    % Try reading as Excel first
    condTable = readtable(fullCondPath, 'ReadVariableNames', false);
catch
    % If Excel fails, try as CSV/delimiter-separated
    try
        % Auto-detect delimiter
        condTable = readtable(fullCondPath, 'ReadVariableNames', false);
    catch
        error('Could not read condition file. Please check format.');
    end
end

% Check if we have enough columns
if size(condTable, 2) < 2
    error('Condition file must have at least 2 columns (animal mark and condition).');
end

% Extract animal marks and conditions
animalMarks = condTable{:,1};  % First column: animal marks
conditions = condTable{:,2};   % Second column: conditions (lines/pois)

% Check for third column (left/right)
hasSideColumn = size(condTable, 2) >= 3;
if hasSideColumn
    sides = condTable{:,3};    % Third column: sides (left/right)
    fprintf('Found side column (left/right) in condition file.\n');
else
    fprintf('No side column found. Only assigning conditions.\n');
end

% Convert animal marks to consistent format (strings)
condAnimals = cellstr(string(animalMarks));

% Initialize CondPattern and Side fields
for i = 1:numel(var)
    % Get current animal mark (remove any trailing spaces)
    currentMark = strtrim(var(i).animalmark);
    
    % Find matching condition
    matchIdx = find(strcmp(condAnimals, currentMark), 1);
    
    if ~isempty(matchIdx)
        % Assign condition if found
        if iscell(conditions)
            var(i).CondPattern = conditions{matchIdx};
        else
            var(i).CondPattern = char(conditions(matchIdx));
        end
        
        % Assign side if available
        if hasSideColumn
            if iscell(sides)
                var(i).Side = sides{matchIdx};
            else
                var(i).Side = char(sides(matchIdx));
            end
        else
            var(i).Side = 'unknown';
        end
    else
        % If no match found, use defaults or warn
        var(i).CondPattern = 'unknown';
        var(i).Side = 'unknown';
        warning('Animal mark "%s" not found in condition file.', currentMark);
    end
end

% Display summary
fprintf('\nCondition and side assignment complete:\n');
fprintf('  - Loaded %d conditions from: %s\n', numel(condAnimals), condFile);
if hasSideColumn
    fprintf('  - Assigned conditions and sides to %d animals\n', numel(var));
else
    fprintf('  - Assigned conditions to %d animals (no side info)\n', numel(var));
end

% Display a quick summary of assignments
fprintf('\nSample assignments:\n');
maxDisplay = min(5, numel(var));
for i = 1:maxDisplay
    fprintf('  Animal %s: %s', var(i).animalmark, var(i).CondPattern);
    if isfield(var, 'Side')
        fprintf(' (%s)', var(i).Side);
    end
    fprintf('\n');
end
if numel(var) > maxDisplay
    fprintf('  ... and %d more animals\n', numel(var) - maxDisplay);
end
fprintf('\n');

%% add cond uncond and corridor as independent variables 
%(check if the columns correspond to your data)
for n = 1:numel(var)
    var(n).corridor = var(n).data(:,18);

    if strcmp(var(n).CondPattern, 'lines')
        var(n).cond = var(n).data(:,17);
        var(n).uncond = var(n).data(:,16);
    elseif strcmp(var(n).CondPattern, 'pois')
        var(n).uncond = var(n).data(:,17);
        var(n).cond = var(n).data(:,16);
    end
end   

%% add velocity and preprocess it
for n = 1:numel(var)
    var(n).velocity = var(n).data(:,14);
end   

%% functions
function trajectories = importTrajectoryData()
[files, path] = uigetfile('*.xlsx', 'Select Excel files', 'MultiSelect', 'on');
if isequal(files, 0)
    trajectories = [];
    return;
end

if ischar(files)
    files = {files};
end
files = fullfile(path, files);

trajectories = struct(...
    'filename', {}, ...
    'category', {}, ...
    'data', {}, ...
    'animalmark', {}, ...
    'fullmetadata', {}, ...
    'pagename', {} ...
    );

for f = 1:numel(files)
    filename = files{f};
    
    try
        % Use sheetnames function (available in R2019b and later)
        sheetNames = sheetnames(filename);
    catch
        % Fall back to xlsfinfo for older MATLAB versions
        [~, sheetNames] = xlsfinfo(filename);
    end
    
    if ischar(sheetNames)
        sheetNames = cellstr(sheetNames);
    end
    
    for s = 1:numel(sheetNames)
        sheetName = sheetNames{s};
        
        try
            % Read entire sheet as cell array
            raw = readcell(filename, 'Sheet', sheetName, 'UseExcel', false);
            
            if isempty(raw)
                continue;
            end
            
            % Handle header line conversion (char to double)
            headerCell = raw{1,2};
            if ischar(headerCell) || isstring(headerCell)
                nHeader = str2double(headerCell);
            else
                nHeader = headerCell;
            end
            
            if isnan(nHeader) || ~isnumeric(nHeader)
                warning('Invalid header count in %s:%s. Using default 40.', filename, sheetName);
                nHeader = 40;
            end
            
            fullmetadata = raw(1:nHeader, :);
            
            % Extract animalmark (row 35) with type handling
            animalmark = '';
            if size(fullmetadata,1) >= 35
                animalmark_val = fullmetadata{35,2};
                if isnumeric(animalmark_val)
                    animalmark = num2str(animalmark_val);
                elseif ischar(animalmark_val) || isstring(animalmark_val)
                    animalmark = char(animalmark_val);
                end
            end
            
            % Extract category (row 36) with type handling
            category = false;
            if size(fullmetadata,1) >= 37
                category_val = fullmetadata{37,2};
                if ischar(category_val) || isstring(category_val)
                    category = strcmpi(char(category_val), 'YES');
                elseif isnumeric(category_val)
                    category = logical(category_val);
                end
            end
            
            % Skip 2 lines below metadata header
            dataStartRow = nHeader + 3;
            if size(raw, 1) < dataStartRow
                data = [];
            else
                dataCells = raw(dataStartRow:end, :);
                data = convertToNumericMatrix(dataCells);
            end
            
            newEntry = struct(...
                'filename', filename, ...
                'category', category, ...
                'data', data, ...
                'animalmark', animalmark, ...
                'fullmetadata', {fullmetadata}, ...
                'pagename', sheetName ...
                );
            trajectories = [trajectories, newEntry];
            
        catch ME
            warning('Error in %s:%s - %s', filename, sheetName, ME.message);
        end
    end
end
end


%%
function numMatrix = convertToNumericMatrix(cellData)
numMatrix = NaN(size(cellData));
for i = 1:size(cellData,1)
    for j = 1:size(cellData,2)
        value = cellData{i,j};
        if isnumeric(value)
            numMatrix(i,j) = value;
        elseif ischar(value) || isstring(value)
            value = char(value);
            if strcmp(value, '-')
                numMatrix(i,j) = NaN;
            else
                % Handle European decimal comma (replace comma with dot)
                if contains(value, ',')
                    value = strrep(value, ',', '.');
                end
                numVal = str2double(value);
                if ~isnan(numVal)
                    numMatrix(i,j) = numVal;
                end
            end
        end
    end
end
end