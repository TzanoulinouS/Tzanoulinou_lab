% MATLAB script to reshape velocity & pause data (no TimeBin in column names)
% Input columns: Animal, DefeatStatus, TestStep, Zone, MeanVelocity, MedianVelocity, PercentPaused
% Output: one row per animal, columns = CPA_TestStep_Total_Zone_MeanVelocity,
%         CPA_TestStep_Total_Zone_MedianVelocity, CPA_TestStep_Total_Zone_PercentPaused
% Rows sorted according to an external animal order file.

clearvars; clc;

%cd 'Z:\FAC\FBM\DSB\stzanoul\social_stress\D2c\Pierre-HuguesSTz\CPA Lausanne MetoficoProcessing\Stamatina8\stats\extracted datasets\VGAT\PausesVelocity VGAT\no chambers';
% 1. Select input data file
[dataFile, dataPath] = uigetfile('*.xlsx', 'Select the input Excel data file');
if isequal(dataFile, 0)
    disp('User canceled input file selection.');
    return;
end
inputFullPath = fullfile(dataPath, dataFile);

% 2. Select animal order file
[orderFile, orderPath] = uigetfile('*.xlsx', 'Select the Excel file with animal order (first column)');
if isequal(orderFile, 0)
    disp('User canceled order file selection.');
    return;
end
orderFullPath = fullfile(orderPath, orderFile);

% 3. Read input data with proper decimal separator (comma)
%   Many European Excel files use comma as decimal separator.
opts = detectImportOptions(inputFullPath);

% Identify columns that are NOT text (i.e., numeric with comma decimal)
textColumns = {'Animal', 'TestStep', 'Zone'};  % keep as text
numericColumns = setdiff(opts.VariableNames, textColumns);

% For numeric columns, set decimal separator to comma
for i = 1:length(numericColumns)
    opts = setvaropts(opts, numericColumns{i}, 'DecimalSeparator', ',');
end

% Force Animal column to be read as string to preserve format (e.g., '30.2')
opts = setvaropts(opts, 'Animal', 'Type', 'string');
% Also ensure TestStep and Zone are read as string
opts = setvaropts(opts, 'TestStep', 'Type', 'string');
opts = setvaropts(opts, 'Zone', 'Type', 'string');

rawData = readtable(inputFullPath, opts);

% Convert relevant columns to string for consistent handling
rawData.Animal = string(rawData.Animal);
rawData.TestStep = string(rawData.TestStep);
rawData.Zone = string(rawData.Zone);

% (Optional) Remove any rows with missing critical data
rawData = rawData(~ismissing(rawData.Animal) & ...
                  ~ismissing(rawData.TestStep) & ...
                  ~ismissing(rawData.Zone), :);

% 4. Read animal order file
orderOpts = detectImportOptions(orderFullPath);
orderOpts = setvaropts(orderOpts, 1, 'Type', 'string'); % first column as string
orderTable = readtable(orderFullPath, orderOpts);
animalOrder = string(orderTable{:, 1});
animalOrder = strip(animalOrder);
animalOrder(animalOrder == "") = [];

% 5. Get unique Animal IDs and their corresponding DefeatStatus
allAnimals = unique(rawData.Animal);
defeatMap = containers.Map;
for i = 1:length(allAnimals)
    aid = allAnimals(i);
    status = rawData.DefeatStatus(rawData.Animal == aid);
    if ~isempty(status)
        defeatMap(char(aid)) = status(1);
    else
        defeatMap(char(aid)) = NaN;
    end
end

% 6. Identify all unique TestStep and Zone combinations
allTestSteps = unique(rawData.TestStep);
allZones = unique(rawData.Zone);
metrics = ["MeanVelocity", "MedianVelocity", "PercentPaused"];

% 7. Generate all column names (as character vectors)
colNames = {};
for ts = sort(allTestSteps)'          % iterate over sorted test steps
    for zn = sort(allZones)'         % iterate over sorted zones
        for met = metrics
            colName = "CPA_" + ts + "_Total_" + zn + "_" + met;
            colNames{end+1} = char(colName);
        end
    end
end
% Remove any potential duplicates (should not happen)
colNames = unique(colNames, 'stable');

% Output table variable names: first two fixed, then the generated ones
outVarNames = ['Animal', 'DefeatStatus', colNames];

% Preallocate output table (one row per animal)
numAnimals = length(allAnimals);
outTable = table('Size', [numAnimals, length(outVarNames)], ...
                 'VariableTypes', [repmat({'string'},1,2), repmat({'double'},1,length(colNames))], ...
                 'VariableNames', outVarNames);

% Fill Animal and DefeatStatus columns
outTable.Animal = allAnimals;
for i = 1:numAnimals
    aid = char(allAnimals(i));
    if isKey(defeatMap, aid)
        outTable.DefeatStatus(i) = defeatMap(aid);
    end
end

% 8. Map column names to indices in output table
colIdxMap = containers.Map;
for j = 1:length(colNames)
    colIdxMap(colNames{j}) = j + 2;   % +2 because first two columns are Animal, DefeatStatus
end

% 9. Populate the metric columns
for k = 1:height(rawData)
    animalID = char(rawData.Animal(k));
    ts = rawData.TestStep(k);
    zn = rawData.Zone(k);
    
    % Find row index in output table for this animal
    rowIdx = find(outTable.Animal == string(animalID), 1);
    if isempty(rowIdx)
        continue;
    end
    
    % MeanVelocity column
    colNameMV = char("CPA_" + ts + "_Total_" + zn + "_MeanVelocity");
    if isKey(colIdxMap, colNameMV) && ~isnan(rawData.MeanVelocity(k))
        outTable{rowIdx, colIdxMap(colNameMV)} = rawData.MeanVelocity(k);
    end
    
    % MedianVelocity column
    colNameMedV = char("CPA_" + ts + "_Total_" + zn + "_MedianVelocity");
    if isKey(colIdxMap, colNameMedV) && ~isnan(rawData.MedianVelocity(k))
        outTable{rowIdx, colIdxMap(colNameMedV)} = rawData.MedianVelocity(k);
    end
    
    % PercentPaused column
    colNamePP = char("CPA_" + ts + "_Total_" + zn + "_PercentPaused");
    if isKey(colIdxMap, colNamePP) && ~isnan(rawData.PercentPaused(k))
        outTable{rowIdx, colIdxMap(colNamePP)} = rawData.PercentPaused(k);
    end
end

% 10. Reorder rows according to the provided animal order
rank = inf(numAnimals, 1);
for i = 1:numAnimals
    pos = find(animalOrder == outTable.Animal(i), 1);
    if ~isempty(pos)
        rank(i) = pos;
    end
end
[~, orderIdx] = sort(rank);
outTable = outTable(orderIdx, :);

% 11. Save the result to a new Excel file
[outFile, outPath] = uiputfile('*.xlsx', 'Save reshaped data as', 'reshaped_no_timebins.xlsx');
if isequal(outFile, 0)
    disp('User canceled save.');
else
    outFullPath = fullfile(outPath, outFile);
    writetable(outTable, outFullPath);
    fprintf('Successfully saved reshaped data to:\n%s\n', outFullPath);
end

disp('Done!');