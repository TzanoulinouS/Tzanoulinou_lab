%% ================= SAFETY FIRST =================
%load a copy of the data structure first
dataStruct = FullCPALausanneAnxiety

%% run the actual script on a clean and safe slate
%clearvars -except dataStruct
assert(isstruct(dataStruct), 'dataStruct must be a struct array');

Fs = 25;
nTimeBins = 1;
outFile1 = 'Behavior_ByZone_TimeBins_Episodes.xlsx';
outFile2 = 'Behavior_ByZone_TimeBins_Totals.xlsx';

% -------- Behavior filtering rules --------
behavior_params.sniff.confidence_threshold = 30;
behavior_params.sniff.min_duration = 0;
behavior_params.rear.confidence_threshold = 70;
behavior_params.rear.min_duration = 0.8;
behavior_params.freeze.confidence_threshold = 50;
behavior_params.freeze.min_duration = 0;
behavior_params.groom.confidence_threshold = 60;
behavior_params.groom.min_duration = 1.5;
behavior_params.neg.confidence_threshold = 0;
behavior_params.neg.min_duration = 0;

% Get list of all behaviors we're tracking (from parameters)
behaviorList = fieldnames(behavior_params);

% ================= MAIN =================
rows_episodes = {};
episodeIdx = 0;
rows_totals = {};
totalIdx = 0;
nTrials = numel(dataStruct);

for idx = 1:nTrials
    S = dataStruct(idx);
    animal = S.animalmark;
    teststep = S.TestStep;
    defeatStatus = S.DefeatStatus;  % ADDED: Get defeat status
    
    % Make sure we have the correct number of frames
    nFrames = min([length(S.corridor), length(S.cond), length(S.uncond)]);
    totalTime_s = nFrames / Fs;
    binEdges = linspace(0, totalTime_s, nTimeBins+1);
    
    % ---- Zones (convert to logical properly) ----
    corridor_vec = S.corridor(1:nFrames);
    cond_vec = S.cond(1:nFrames);
    uncond_vec = S.uncond(1:nFrames);
    
    zones = struct();
    zones.corridor = corridor_vec > 0.5;
    zones.cond = cond_vec > 0.5;
    zones.uncond = uncond_vec > 0.5;
    
    zoneNames = fieldnames(zones);
    
    % ---- Behavior table ----
    BT = S.BehaviourTimestamps;
    
    %% -------- Filter behaviors --------
    if isempty(BT)
        % If no behavior data, still need to create zero entries for all combinations
        % We'll handle this after the filtering section
        BT_filtered = [];
    else
        keep = false(height(BT),1);
        for b = 1:height(BT)
            beh_raw = BT.Behaviour_Type{b};
            if isempty(beh_raw)
                continue;
            end
            beh = lower(strtrim(beh_raw));
            
            % Clean behavior name - remove numbers after behavior names
            beh_parts = strsplit(beh);
            if ~isempty(beh_parts)
                base_beh = beh_parts{1};
            else
                base_beh = beh;
            end
            
            % Handle special cases
            if contains(base_beh, 'neg')
                base_beh = 'neg';
            end
            
            % Check if this base behavior is in our parameters
            if ~isfield(behavior_params, base_beh)
                % Try to find matching behavior name
                possible_fields = fieldnames(behavior_params);
                found = false;
                for f = 1:length(possible_fields)
                    if contains(base_beh, possible_fields{f}) || contains(possible_fields{f}, base_beh)
                        base_beh = possible_fields{f};
                        found = true;
                        break;
                    end
                end
                if ~found
                    continue;
                end
            end
            
            keep(b) = ...
                BT.Confidence_percent_(b) >= behavior_params.(base_beh).confidence_threshold && ...
                BT.Duration_clean(b) >= behavior_params.(base_beh).min_duration;
        end
        
        BT_filtered = BT(keep,:);
        
        if ~isempty(BT_filtered)
            % Clean behavior names in the filtered table (remove numbers)
            for b = 1:height(BT_filtered)
                beh = lower(strtrim(BT_filtered.Behaviour_Type{b}));
                beh_parts = strsplit(beh);
                if ~isempty(beh_parts)
                    base_beh = beh_parts{1};
                else
                    base_beh = beh;
                end
                
                if contains(base_beh, 'neg')
                    base_beh = 'neg';
                end
                
                BT_filtered.Behaviour_Type{b} = base_beh;
            end
        end
    end
    
    %% -------- Time bins --------
    for tb = 1:nTimeBins
        binStart = binEdges(tb);
        binEnd = binEdges(tb+1);
        binDuration = binEnd - binStart;
        
        fStart = max(1, floor(binStart * Fs) + 1);
        fEnd = min(nFrames, floor(binEnd * Fs));
        
        if fEnd < fStart
            continue;
        end
        
        binFrames = fStart:fEnd;
        
        %% -------- Process each zone --------
        for z = 1:numel(zoneNames)
            zName = zoneNames{z};
            zVec = zones.(zName);
            
            if length(zVec) < max(binFrames)
                continue;
            end
            
            % Calculate time spent in this zone during this bin
            zoneFrames = zVec(binFrames);
            zoneTime_s = sum(zoneFrames) / Fs;
            
            % Prepare to track episodes for each behavior
            episodeData = containers.Map('KeyType', 'char', 'ValueType', 'any');
            
            % Initialize episodeData for all behaviors
            for bb = 1:numel(behaviorList)
                beh = behaviorList{bb};
                episodeData(beh) = struct('totalTime_s', 0, 'episodeCount', 0, 'episodeDetails', []);
            end
            
            %% -------- Process behaviors if we have data --------
            if ~isempty(BT_filtered)
                % Get unique behaviors in filtered data
                if ~isempty(BT_filtered)
                    behaviorsInData = unique(BT_filtered.Behaviour_Type);
                else
                    behaviorsInData = {};
                end
                
                for bb = 1:numel(behaviorsInData)
                    beh = behaviorsInData{bb};
                    
                    % Find rows for this behavior
                    idxB = strcmpi(BT_filtered.Behaviour_Type, beh);
                    if ~any(idxB)
                        continue;
                    end
                    
                    inT = BT_filtered.In_Time_clean(idxB);
                    outT = BT_filtered.Out_Time_clean(idxB);
                    
                    % Calculate overlap for each episode
                    episodeCount = 0;
                    
                    for ep = 1:numel(inT)
                        % Calculate overlap between behavior episode and time bin
                        overlapStart = max(inT(ep), binStart);
                        overlapEnd = min(outT(ep), binEnd);
                        overlapDur = max(0, overlapEnd - overlapStart);
                        
                        if overlapDur > 0
                            % Convert to frames for zone checking
                            f1 = max(fStart, floor(overlapStart * Fs) + 1);
                            f2 = min(fEnd, floor(overlapEnd * Fs));
                            
                            if f2 >= f1
                                % Check which of these frames are in the zone
                                framesInZone = find(zVec(f1:f2));
                                
                                if ~isempty(framesInZone)
                                    episodeTime = length(framesInZone) / Fs;
                                    
                                    % Update episode data
                                    currentData = episodeData(beh);
                                    currentData.totalTime_s = currentData.totalTime_s + episodeTime;
                                    currentData.episodeCount = currentData.episodeCount + 1;
                                    currentData.episodeDetails = [currentData.episodeDetails; episodeTime];
                                    episodeData(beh) = currentData;
                                    
                                    % Add to episodes table
                                    episodeIdx = episodeIdx + 1;
                                    rows_episodes{episodeIdx, 1} = animal;
                                    rows_episodes{episodeIdx, 2} = teststep;
                                    rows_episodes{episodeIdx, 3} = tb;
                                    rows_episodes{episodeIdx, 4} = zName;
                                    rows_episodes{episodeIdx, 5} = beh;
                                    rows_episodes{episodeIdx, 6} = episodeTime;
                                    if zoneTime_s > 0
                                        rows_episodes{episodeIdx, 7} = 100 * episodeTime / zoneTime_s;
                                    else
                                        rows_episodes{episodeIdx, 7} = 0;
                                    end
                                    rows_episodes{episodeIdx, 8} = currentData.episodeCount;  % Episode number
                                    rows_episodes{episodeIdx, 9} = defeatStatus;  % ADDED: DefeatStatus
                                end
                            end
                        end
                    end
                end
            end
            
            %% -------- Create entries for ALL behaviors (even zero ones) --------
            for bb = 1:numel(behaviorList)
                beh = behaviorList{bb};
                behaviorData = episodeData(beh);
                totalTime_s = behaviorData.totalTime_s;
                episodeCount = behaviorData.episodeCount;
                
                % Always create an entry, even if totalTime_s = 0
                % Calculate percentages (handle division by zero)
                if zoneTime_s > 0
                    pctZone = 100 * totalTime_s / zoneTime_s;
                else
                    pctZone = 0;
                end
                
                if binDuration > 0
                    pctBin = 100 * totalTime_s / binDuration;
                else
                    pctBin = 0;
                end
                
                totalIdx = totalIdx + 1;
                rows_totals{totalIdx, 1} = animal;
                rows_totals{totalIdx, 2} = teststep;
                rows_totals{totalIdx, 3} = tb;
                rows_totals{totalIdx, 4} = zName;
                rows_totals{totalIdx, 5} = beh;
                rows_totals{totalIdx, 6} = binDuration;
                rows_totals{totalIdx, 7} = zoneTime_s;
                rows_totals{totalIdx, 8} = totalTime_s;
                rows_totals{totalIdx, 9} = pctZone;
                rows_totals{totalIdx, 10} = pctBin;
                rows_totals{totalIdx, 11} = episodeCount;
                rows_totals{totalIdx, 12} = defeatStatus;  % ADDED: DefeatStatus
            end
        end
    end
end

% ================= EXPORT EPISODES =================
varNamesEpisodes = { ...
    'Animal', ...
    'TestStep', ...
    'TimeBin', ...
    'Zone', ...
    'Behavior', ...
    'Time_s', ...
    'Pct_of_zone_time', ...
    'Episode_number', ...
    'DefeatStatus' };  % ADDED: DefeatStatus

if isempty(rows_episodes)
    T_episodes = cell2table(cell(0, numel(varNamesEpisodes)), 'VariableNames', varNamesEpisodes);
    fprintf('No episode data found!\n');
else
    if iscell(rows_episodes) && size(rows_episodes, 2) < numel(varNamesEpisodes)
        rows_episodes = rows_episodes';
    end
    T_episodes = cell2table(rows_episodes, 'VariableNames', varNamesEpisodes);
    T_episodes = sortrows(T_episodes, {'Animal', 'TestStep', 'TimeBin', 'Zone', 'Behavior', 'Episode_number'});
end

writetable(T_episodes, outFile1);
fprintf('Episode export complete: %s\n', outFile1);

% ================= EXPORT TOTALS =================
varNamesTotals = { ...
    'Animal', ...
    'TestStep', ...
    'TimeBin', ...
    'Zone', ...
    'Behavior', ...
    'BinDuration_s', ...
    'ZoneTime_s', ...
    'TotalBehaviorTime_s', ...
    'Pct_of_zone_time', ...
    'Pct_of_bin_time', ...
    'N_episodes', ...
    'DefeatStatus' };  % ADDED: DefeatStatus

if isempty(rows_totals)
    T_totals = cell2table(cell(0, numel(varNamesTotals)), 'VariableNames', varNamesTotals);
    fprintf('No aggregated data found!\n');
else
    if iscell(rows_totals) && size(rows_totals, 2) < numel(varNamesTotals)
        rows_totals = rows_totals';
    end
    T_totals = cell2table(rows_totals, 'VariableNames', varNamesTotals);
    T_totals = sortrows(T_totals, {'Animal', 'TestStep', 'TimeBin', 'Zone', 'Behavior'});
end

writetable(T_totals, outFile2);
fprintf('Aggregated export complete: %s\n', outFile2);

% Display summaries
fprintf('\n===== SUMMARY =====\n');
if ~isempty(T_episodes)
    fprintf('Episode file: %d rows (only actual episodes)\n', height(T_episodes));
end
if ~isempty(T_totals)
    fprintf('Totals file: %d rows (all combinations, including zeros)\n', height(T_totals));
    
    % Count zero entries
    zeroEntries = sum(T_totals.TotalBehaviorTime_s == 0);
    nonZeroEntries = sum(T_totals.TotalBehaviorTime_s > 0);
    
    fprintf('  Non-zero entries: %d\n', nonZeroEntries);
    fprintf('  Zero entries: %d\n', zeroEntries);
    
    % Show behaviors found
    uniqueBehaviors = unique(T_totals.Behavior);
    fprintf('Behaviors tracked: %s\n', strjoin(uniqueBehaviors', ', '));
    
    % Show sample of zero entries
    zeroRows = T_totals(T_totals.TotalBehaviorTime_s == 0, :);
    if ~isempty(zeroRows)
        fprintf('\nSample of zero-entries (showing first 5):\n');
        disp(zeroRows(1:min(5, height(zeroRows)), :));
    end
end