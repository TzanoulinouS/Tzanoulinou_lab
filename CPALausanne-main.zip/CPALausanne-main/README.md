# CPALausanne
The repository for the code and data used in the publication Parapera papantoniou, et al.
This repository includes the data structure used in the final publication, these structures are composed of tracking data imported from ethovision and behavioral data imported from Metofico's behavior detection model. 
The model used for this publication is for Sniffing Grooming, Rearing, Freezing and negative and is called Stamatina8
This script will not include import scripts for ethovision and metofico import but raw excel files are available on request.
