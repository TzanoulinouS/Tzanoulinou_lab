% MATLAB script to reshape transition & velocity data (with TimeBin in column names)
% Input columns: Animal, DefeatStatus, TestStep, TimeBin, Zone,
%                TransitionCount, MeanPeakVelocity, MeanMedianVelocity, MeanAUC
% Output: one row per animal, columns = CPA_TestStep_TimeBin_Zone_Metric
% Rows sorted according to an external animal order file.

clearvars; clc;

% 1. Select input data file
[dataFile, dataPath] = uigetfile('*.xlsx', 'Select the input Excel data file');
if isequal(dataFile, 0)
    disp('User canceled input file selection.');
    return;
end
inputFullPath = fullfile(dataPath, dataFile);

% 2. Select animal order file
[orderFile, orderPath] = uigetfile('*.xlsx', 'Select the Excel file with animal order (first column)');
if isequal(orderFile, 0)
    disp('User canceled order file selection.');
    return;
end
orderFullPath = fullfile(orderPath, orderFile);

% 3. Read input data with proper decimal separator (comma)
opts = detectImportOptions(inputFullPath);

% Identify text vs numeric columns
textColumns = {'Animal', 'TestStep', 'Zone'};
numericColumns = setdiff(opts.VariableNames, textColumns);

% For numeric columns, set decimal separator to comma
for i = 1:length(numericColumns)
    opts = setvaropts(opts, numericColumns{i}, 'DecimalSeparator', ',');
end

% Force string columns
opts = setvaropts(opts, 'Animal',   'Type', 'string');
opts = setvaropts(opts, 'TestStep', 'Type', 'string');
opts = setvaropts(opts, 'Zone',     'Type', 'string');

rawData = readtable(inputFullPath, opts);

% Convert to string for consistent handling
rawData.Animal   = string(rawData.Animal);
rawData.TestStep = string(rawData.TestStep);
rawData.Zone     = string(rawData.Zone);

% Remove rows with missing critical data
rawData = rawData(~ismissing(rawData.Animal)   & ...
                  ~ismissing(rawData.TestStep) & ...
                  ~ismissing(rawData.Zone), :);

% 4. Read animal order file
orderOpts = detectImportOptions(orderFullPath);
orderOpts = setvaropts(orderOpts, 1, 'Type', 'string');
orderTable = readtable(orderFullPath, orderOpts);
animalOrder = string(orderTable{:, 1});
animalOrder = strip(animalOrder);
animalOrder(animalOrder == "") = [];

% 5. Get unique Animal IDs and their corresponding DefeatStatus
allAnimals = unique(rawData.Animal);
defeatMap  = containers.Map;
for i = 1:length(allAnimals)
    aid    = allAnimals(i);
    status = rawData.DefeatStatus(rawData.Animal == aid);
    if ~isempty(status)
        defeatMap(char(aid)) = status(1);
    else
        defeatMap(char(aid)) = NaN;
    end
end

% 6. Identify all unique combinations of TestStep, TimeBin, Zone
allTestSteps = unique(rawData.TestStep);
allTimeBins  = unique(rawData.TimeBin);   % numeric
allZones     = unique(rawData.Zone);
metrics      = ["TransitionCount", "MeanPeakVelocity", "MeanMedianVelocity", "MeanAUC"];

% 7. Generate all column names
colNames = {};
for ts = sort(allTestSteps)'
    for tb = sort(allTimeBins)'
        for zn = sort(allZones)'
            for met = metrics
                colName = "CPA_" + ts + "_" + string(tb) + "_" + zn + "_" + met;
                colNames{end+1} = char(colName);
            end
        end
    end
end
colNames = unique(colNames, 'stable');

% Output table variable names: first two fixed, then the generated ones
outVarNames = ['Animal', 'DefeatStatus', colNames];

% Preallocate output table (one row per animal)
numAnimals = length(allAnimals);
outTable = table('Size', [numAnimals, length(outVarNames)], ...
                 'VariableTypes', [repmat({'string'}, 1, 2), repmat({'double'}, 1, length(colNames))], ...
                 'VariableNames', outVarNames);

% Fill Animal and DefeatStatus columns
outTable.Animal = allAnimals;
for i = 1:numAnimals
    aid = char(allAnimals(i));
    if isKey(defeatMap, aid)
        outTable.DefeatStatus(i) = defeatMap(aid);
    end
end

% 8. Map column names to indices in output table
colIdxMap = containers.Map;
for j = 1:length(colNames)
    colIdxMap(colNames{j}) = j + 2;  % +2 for Animal, DefeatStatus
end

% 9. Populate the metric columns
for k = 1:height(rawData)
    animalID = char(rawData.Animal(k));
    ts  = rawData.TestStep(k);
    tb  = rawData.TimeBin(k);     % numeric
    zn  = rawData.Zone(k);

    % Find row index in output table for this animal
    rowIdx = find(outTable.Animal == string(animalID), 1);
    if isempty(rowIdx)
        continue;
    end

    % Build base prefix for this combination
    prefix = "CPA_" + ts + "_" + string(tb) + "_" + zn + "_";

    % TransitionCount
    cn = char(prefix + "TransitionCount");
    if isKey(colIdxMap, cn) && ~isnan(rawData.TransitionCount(k))
        outTable{rowIdx, colIdxMap(cn)} = rawData.TransitionCount(k);
    end

    % MeanPeakVelocity
    cn = char(prefix + "MeanPeakVelocity");
    if isKey(colIdxMap, cn) && ~isnan(rawData.MeanPeakVelocity(k))
        outTable{rowIdx, colIdxMap(cn)} = rawData.MeanPeakVelocity(k);
    end

    % MeanMedianVelocity
    cn = char(prefix + "MeanMedianVelocity");
    if isKey(colIdxMap, cn) && ~isnan(rawData.MeanMedianVelocity(k))
        outTable{rowIdx, colIdxMap(cn)} = rawData.MeanMedianVelocity(k);
    end

    % MeanAUC
    cn = char(prefix + "MeanAUC");
    if isKey(colIdxMap, cn) && ~isnan(rawData.MeanAUC(k))
        outTable{rowIdx, colIdxMap(cn)} = rawData.MeanAUC(k);
    end
end

% 10. Reorder rows according to the provided animal order
rank = inf(numAnimals, 1);
for i = 1:numAnimals
    pos = find(animalOrder == outTable.Animal(i), 1);
    if ~isempty(pos)
        rank(i) = pos;
    end
end
[~, orderIdx] = sort(rank);
outTable = outTable(orderIdx, :);

% 11. Save the result to a new Excel file
[outFile, outPath] = uiputfile('*.xlsx', 'Save reshaped data as', 'reshaped_with_timebins.xlsx');
if isequal(outFile, 0)
    disp('User canceled save.');
else
    outFullPath = fullfile(outPath, outFile);
    writetable(outTable, outFullPath);
    fprintf('Successfully saved reshaped data to:\n%s\n', outFullPath);
end

disp('Done!');